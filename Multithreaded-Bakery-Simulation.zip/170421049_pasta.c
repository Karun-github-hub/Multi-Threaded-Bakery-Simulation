#include <pthread.h>
#include <semaphore.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>
#include <unistd.h>

#define NUM_USTA 6
#define MALZEME_BOYUT 2
// Toptancı ve ustalar arasında haberleşmeyi sağlayacak semaforlar ve kritik
// bölge kontrolü için mutex tanımları.

// Toptancı ve ustaların paylaştıkları semaforlar
sem_t toptanci_sem;
sem_t usta_sem[NUM_USTA];
// Ustaların malzemeye erişimini kontrol eden mutex
pthread_mutex_t mutex;
// Toptancının teslim ettiği malzemeler
char malzemeler[MALZEME_BOYUT];
int malzeme_var = 0; // Malzeme var mı yok mu kontrolü

int done = 0; // İşin bitip bitmediğini kontrol etmek için bayrak
// Usta yapısı
typedef struct {
  char malzeme1;
  char malzeme2;
  char eksik1;
  char eksik2;
} Usta;
// Her ustaya ait malzeme bilgileri
Usta ustalar[NUM_USTA] = {{'Y', 'U', 'S', 'K'}, {'Y', 'K', 'U', 'S'},
                          {'Y', 'S', 'K', 'U'}, {'U', 'K', 'Y', 'S'},
                          {'U', 'S', 'Y', 'K'}, {'S', 'K', 'Y', 'U'}};

// Malzeme isimlerini döndüren fonksiyon
const char *malzeme_adi(char malzeme) {
  switch (malzeme) {
  case 'Y':
    return "yumurta";
  case 'U':
    return "un";
  case 'S':
    return "süt";
  case 'K':
    return "kakao";
  default:
    return "";
  }
}
// Toptancı işlevi
void *toptanci(void *arg) {
  // Verilen dosya yoluyla dosya açılır
  FILE *file = fopen((char *)arg, "r");
  // Dosya açma işlemi başarısız olursa hata mesajı yazdırılır ve program
  // sonlandırılır
  if (file == NULL) {
    fprintf(stderr, "Dosya okunamadı.\n");
    exit(1);
  }

  char malzeme[MALZEME_BOYUT + 1];
  while (fscanf(file, "%s", malzeme) == 1) {
    // Kritik bölgeye girmek için mutex'i kilitler
    pthread_mutex_lock(&mutex);
    malzemeler[0] =
        malzeme[0]; // İlk malzemeyi malzemeler dizisinin ilk elemanına atar
    malzemeler[1] = malzeme[1]; // İkinci malzemeyi malzemeler dizisinin ikinci
                                // elemanına atar
    malzeme_var = 1;            // Malzeme var olduğunu gösterir

    printf("Toptancı %s ve %s teslim ediyor.\n", malzeme_adi(malzemeler[0]),
           malzeme_adi(malzemeler[1]));

    pthread_mutex_unlock(&mutex); // Kritik bölgeyi serbest bırakır

    for (int i = 0; i < NUM_USTA; i++) {
      sem_post(&usta_sem[i]); // Her usta için semafor sinyalini gönderir
    }

    sem_wait(&toptanci_sem); // // Toptancı, yeni bir sipariş almak için bekler
  }

  fclose(file); // Dosyayı kapatır

  done = 1; // İşin bittiğini gösterir
  for (int i = 0; i < NUM_USTA; i++) {
    sem_post(&usta_sem[i]); // Ustalar için semafor sinyalini gönderir
  }
  printf("Toptancı işini bitirdi. Ustalar daha fazla malzeme alamayacak.\n");

  return NULL;
}

void *usta(void *arg) {
  int usta_id = *(int *)arg; // Ustanın ID'sini al
  free(
      arg); // Ustanın ID'si için dinamik olarak ayrılan belleği serbest bırakır

  while (!done) {                 // İş bitene kadar döngüyü sürdürür
    sem_wait(&usta_sem[usta_id]); // Toptancıdan gelen sinyali bekler

    if (done) { // İş bittiyse, döngüden çıkar
      break;
    }

    pthread_mutex_lock(
        &mutex); // Paylaşılan kaynakları kullanmak için muteksi kilitler
    if (malzeme_var &&
        ((malzemeler[0] ==
              ustalar[usta_id].eksik1 && // Gerekli malzemelerin mevcut olup
                                         // olmadığını kontrol eder
          malzemeler[1] == ustalar[usta_id].eksik2) ||
         (malzemeler[0] == ustalar[usta_id].eksik2 &&
          malzemeler[1] == ustalar[usta_id].eksik1))) {
      malzeme_var = 0; // Malzemelerin kullanıldığını gösterir
      // Ustanın ve ihtiyaç duyduğu malzemelerin bilgisini yazdırır
      printf("Usta%d %s ve %s için bekliyordu.\n", usta_id + 1,
             malzeme_adi(ustalar[usta_id].eksik1),
             malzeme_adi(ustalar[usta_id].eksik2));
      printf("Usta%d %s aldı\n", usta_id + 1, malzeme_adi(malzemeler[0]));
      printf("Toptancı pastayı bekliyor\n");
      printf("Usta%d %s aldı\n", usta_id + 1, malzeme_adi(malzemeler[1]));
      printf("Usta%d pastayı hazırlıyor\n", usta_id + 1);
      pthread_mutex_unlock(&mutex); // Muteksi serbest bırakılır

      sleep(rand() % 5 + 1); // Pasta hazırlama süresi

      printf("Usta%d pastayı toptancıya teslim etti\n", usta_id + 1);
      printf("Toptancı pastayı aldı ve satmaya gitti\n");
      sem_post(&toptanci_sem); // Toptancıya çalışmaya devam etmesi için sinyal
                               // gönderir

      pthread_mutex_lock(
          &mutex); // Paylaşılan kaynakları kullanmak için muteks kilitlenir

      for (int i = 0; i < NUM_USTA;
           i++) { // Diğer ustaların bekleme durumlarını yazdırır
        printf("Usta%d %s ve %s için beklemektedir.\n", i + 1,
               malzeme_adi(ustalar[i].eksik1), malzeme_adi(ustalar[i].eksik2));
      }
      pthread_mutex_unlock(
          &mutex); // Paylaşılan kaynakların kullanımı tamamlandığı için muteks
                   // serbest bırakılır
    } else {
      pthread_mutex_unlock(
          &mutex); // Paylaşılan kaynakların kullanımı tamamlandındığı için
                   // muteks serbest bırakılır
    }
  }
  // Tüm iş tamamlandığında fonksiyon sonlanır
  return NULL;
}

int main(int argc, char *argv[]) {
  // Komut satırı argümanlarının doğruluğunu kontrol eder
  if (argc != 3 || strcmp(argv[1], "-i") != 0) {
    printf("Kullanım: %s -i <dosya_yolu>\n", argv[0]);
    return 1;
  }
  // Tüm ustaların bekleme durumlarını yazdırır
  for (int i = 0; i < NUM_USTA; i++) {
    printf("Usta%d %s ve %s için beklemektedir.\n", i + 1,
           malzeme_adi(ustalar[i].eksik1), malzeme_adi(ustalar[i].eksik2));
  }

  srand(time(NULL));
  // Mutex ve semaforları başlatma
  pthread_mutex_init(&mutex, NULL);
  sem_init(&toptanci_sem, 0, 0);
  for (int i = 0; i < NUM_USTA; i++) {
    sem_init(&usta_sem[i], 0, 0);
  }
  // Usta threadlerini başlatma
  pthread_t usta_threads[NUM_USTA];
  for (int i = 0; i < NUM_USTA; i++) {
    int *usta_id = malloc(sizeof(int));
    *usta_id = i;
    pthread_create(&usta_threads[i], NULL, usta, usta_id);
  }
  // Toptancı threadini başlatma
  pthread_t toptanci_thread;
  pthread_create(&toptanci_thread, NULL, toptanci, argv[2]);
  // Toptancı ve usta threadlerinin bitmesini bekleme
  pthread_join(toptanci_thread, NULL);
  for (int i = 0; i < NUM_USTA; i++) {
    pthread_join(usta_threads[i], NULL);
  }
  // Mutex ve semaforları serbest bırakma
  sem_destroy(&toptanci_sem);
  for (int i = 0; i < NUM_USTA; i++) {
    sem_destroy(&usta_sem[i]);
  }
  pthread_mutex_destroy(&mutex);

  return 0;
}


